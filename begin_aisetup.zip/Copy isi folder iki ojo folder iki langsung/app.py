from flask import Flask, render_template, Response, jsonify, request
import cv2
import numpy as np
from ultralytics import YOLO
import base64
import io
from PIL import Image
import threading
import time
import os
import sys
import json

app = Flask(__name__)

# Check if running in Codespaces or environment without camera
IS_CODESPACES = os.environ.get('CODESPACES') == 'true' or '--demo-mode' in sys.argv

# Load YOLO model
try:
    model = YOLO('yolov8n.pt')
    print("YOLO model loaded successfully!")
except Exception as e:
    print(f"Error loading YOLO model: {e}")
    model = None

class VideoProcessor:
    def __init__(self):
        self.latest_frame = None
        self.processed_frame = None
        self.is_processing = False
        self.frame_lock = threading.Lock()
        self.last_update = 0
        
    def process_frame(self, frame_data):
        """Process frame from browser camera"""
        try:
            if not model:
                return None
                
            # Decode base64 image
            if frame_data.startswith('data:image'):
                frame_data = frame_data.split(',')[1]
            
            # Decode image
            image_data = base64.b64decode(frame_data)
            image = Image.open(io.BytesIO(image_data))
            frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
            
            # Run YOLO detection
            results = model(frame)
            
            # Draw bounding boxes
            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for box in boxes:
                        # Get coordinates
                        x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                        confidence = box.conf[0].cpu().numpy()
                        class_id = int(box.cls[0].cpu().numpy())
                        
                        # Get class name
                        class_name = model.names[class_id]
                        
                        # Draw bounding box
                        cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
                        
                        # Draw label
                        label = f'{class_name}: {confidence:.2f}'
                        cv2.putText(frame, label, (int(x1), int(y1) - 10), 
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            
            # Convert processed frame back to base64
            _, buffer = cv2.imencode('.jpg', frame)
            processed_base64 = base64.b64encode(buffer).decode('utf-8')
            
            return f"data:image/jpeg;base64,{processed_base64}"
            
        except Exception as e:
            print(f"Error processing frame: {e}")
            return None
    
    def update_frame(self, frame_data):
        """Update the latest frame"""
        with self.frame_lock:
            self.latest_frame = frame_data
            self.last_update = time.time()
    
    def get_processed_frame(self):
        """Get the latest processed frame"""
        with self.frame_lock:
            if self.latest_frame and (time.time() - self.last_update < 1.0):
                # Process the frame
                processed = self.process_frame(self.latest_frame)
                if processed:
                    self.processed_frame = processed
                return self.processed_frame
            return None

# Global video processor
video_processor = VideoProcessor()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process_frame', methods=['POST'])
def process_frame():
    """Process a single frame from browser camera"""
    try:
        data = request.get_json()
        frame_data = data.get('frame')
        
        if not frame_data:
            return jsonify({'status': 'error', 'message': 'No frame data'})
        
        # Update the processor with new frame
        video_processor.update_frame(frame_data)
        
        # Process and return result
        processed_frame = video_processor.get_processed_frame()
        
        if processed_frame:
            return jsonify({
                'status': 'success', 
                'processed_frame': processed_frame
            })
        else:
            return jsonify({'status': 'error', 'message': 'Failed to process frame'})
            
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/upload_image', methods=['POST'])
def upload_image():
    """Process uploaded image"""
    try:
        if 'file' not in request.files:
            return jsonify({'status': 'error', 'message': 'No file uploaded'})
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'status': 'error', 'message': 'No file selected'})
        
        # Read image
        image = Image.open(file.stream)
        frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        
        if model:
            # Run YOLO detection
            results = model(frame)
            
            # Draw bounding boxes
            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for box in boxes:
                        # Get coordinates
                        x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                        confidence = box.conf[0].cpu().numpy()
                        class_id = int(box.cls[0].cpu().numpy())
                        
                        # Get class name
                        class_name = model.names[class_id]
                        
                        # Draw bounding box
                        cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
                        
                        # Draw label
                        label = f'{class_name}: {confidence:.2f}'
                        cv2.putText(frame, label, (int(x1), int(y1) - 10), 
                                  cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        # Convert back to base64 for response
        _, buffer = cv2.imencode('.jpg', frame)
        img_base64 = base64.b64encode(buffer).decode('utf-8')
        
        return jsonify({
            'status': 'success', 
            'image': f'data:image/jpeg;base64,{img_base64}'
        })
        
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/camera_status')
def camera_status():
    return jsonify({
        'is_codespaces': IS_CODESPACES,
        'model_loaded': model is not None
    })

if __name__ == '__main__':
    print(f"Running in {'Codespaces' if IS_CODESPACES else 'Local'} mode")
    print("Real-time camera processing enabled via WebRTC")
    app.run(debug=True, host='0.0.0.0', port=5000)